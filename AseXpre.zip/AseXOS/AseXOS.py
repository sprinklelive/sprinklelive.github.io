import sys
import time
import os
import datetime
from datetime import datetime

print("Starting BIOS...")
time.sleep(1)
print("Starting System...")
time.sleep(1)
print(" ")
Login = input("Login > ")
if Login == 'Admin':
    Login = 'Admin'
elif Login == '010100110111100101110011011101000110010101101101':
    Login = 'System'
else:
    Login = 'User'
print(" ")
print('AseX Oprating System - Core ©2020 All right reserved')
time.sleep(0.3)
print("Type 'cmdlist' for Commandlist")
while True:
    command = input('[ User:'+Login+' ] > ')
    if command == 'cmdlist':
        print('AseX/Command1list - cmdlist\Show command list')
        time.sleep(0.05)
        print('AseX/Command2list - applist\Show all apps')
        time.sleep(0.05)
        print('AseX/Command3list - shell\AseX shell')
        time.sleep(0.05)
        print('AseX/Command4list - newfile\Create a new file')
        time.sleep(0.05)
        print('AseX/Command5list - openfile\Open a file')
        time.sleep(0.05)
        print('AseX/Command6list - time\Print datetime')
        time.sleep(0.05)
        print('AseX/Command7list - ver\Output version')
        time.sleep(0.05)
        print('AseX/Command8list - logoff\Logoff AseX OS')
        time.sleep(0.05)
        print('AseX/Command9list - exit\Exit AseX OS')
    elif command == 'newfile':
        fileName = input('Filename > ')
        if (fileName == ''):
            print("Error/Filename error")
            continue
        else:
            print('Creating......')
            newFile = open(fileName, "w")
            fileContent = input('Type > ')
            newFile.write(fileContent)
            print('File saved')
            newFile.close()
    elif command == 'openfile':
        try:
            fileName = input('Filename > ')
            seeFile = open(fileName, "r")
            text = seeFile.readline()
            seeFile.close()
            print('Openfile:', text)
        except:
            print('Error/openFile error')
            continue
    elif command == 'ver':
        print("&   &  AseX Oprating System - Core")
        time.sleep(0.05)
        print(" & &   Aser inc. ©2020 All right reserved")
        time.sleep(0.05)
        print("  &    AseX kernel Copyright ©2020")
        time.sleep(0.05)
        print(" & &   AseX OS Version:1.0 - Core")
        time.sleep(0.05)
        print("&   &  Login:",Login)
    elif command == 'exit':
        print('Closing...')
        time.sleep(0.5)
        break
    elif command == 'time':
        print(datetime.now())
    elif command == 'applist':
        print(" Applist")
        time.sleep(0.05)
        print("AseX/App1list - vos\AseX Vitual OS")
        time.sleep(0.05)
        print("AseX/App1list - browser\AseX Browser")
    elif command == "vos":
        print(" >AseX Vitual OS ©2020 All right reserved")
        time.sleep(1)
        while True:
            vs = input(" Vitual >")
            if vs == "CodeOS":
                print(" ")
                print(" Starting Vitual Machine...")
                time.sleep(1)
                print(" Installing BIOS...")
                time.sleep(1)
                print(" Installing System...")
                time.sleep(3)
                print(" ")
                print(" Code OS 5.0")
                time.sleep(0.05)
                print(" Type list for command list")
                while True:
                    cmd = input(" > ")
                    if cmd == 'list':
                        print(" list > list/output command list")
                        time.sleep(0.05)
                        print(" list > ver/check Code OS version")
                        time.sleep(0.05)
                        print(" list > new/create a new file")
                        time.sleep(0.05)
                        print(" list > open/open a file")
                        time.sleep(0.05)
                        print(" list > time/check datetime")
                        time.sleep(0.05)
                        print(" list > logout/close Code OS")
                    elif cmd == 'ver':
                        print(" ver > Code Oprating System ©2020 All right reserved")
                        time.sleep(0.05)
                        print(" Copyright > Aser Technology.inc")
                        time.sleep(0.05)
                        print(" num > 2080-5084-70-021")
                    elif cmd == 'new':
                        fname = input(' Filename >')
                        if (fname == ''):
                            print(" error > Filename cannot be empty")
                            continue
                        else:
                            print(' >creating... ')
                            newf = open(fname, "w")
                            fc = input(' write >')
                            newf.write(fc)
                            print(' Done')
                            newf.close()
                    elif cmd == 'open':
                        try:
                            fname = input(' FileName >')
                            seef = open(fname, "r")
                            txt = seef.readline()
                            seef.close()
                            print(' File/', txt)
                        except:
                            print(' error > Cannot find the file')
                            continue
                    elif cmd == 'time':
                        print(' ',datetime.now())
                    elif cmd == 'logout':
                        print(" Closing...")
                        time.sleep(3)
                        break
                    elif cmd == '':
                        continue
                    else:
                        print(" error > Cannot find '",cmd,"'")
            elif vs == "loados":
                loados = input(" LoadOS Disk>")
                os.system(loados)
            elif vs == "exit":
                break
            elif vs == "help":
                print(" HelpList")
                time.sleep(0.05)
                print(" |ZoreOS > Run ZoreOS locally")
                time.sleep(0.05)
                print(" |loados > Load OS Disk")
                time.sleep(0.05)
                print(" |exit > Quit Vitual System")
            elif vs == "":
                continue
            else:
                print(" Error Vitual System command")
    elif command == 'browser':
        import Browser
    elif command == 'shell' and Login != 'User':
        print(" AseX shell 15.0")
        while True:
            shell = input(" $ ")
            if shell == 'platform':
                print(" ",sys.platform)
            elif shell == 'version':
                print(" ",sys.version)
            elif shell == 'copyright':
                print(" ",sys.copyright)
            elif shell == 'time':
                print(" ",datetime.now())
            elif shell == 'run':
                srun = input(" $ run ")
                os.system(srun)
            elif shell == 'cmd':
                os.system(shell)
            elif shell == 'exit':
                break
            elif shell == '':
                continue
            else:
                print(" Error command")
    elif command == '':
        continue
    else:
        print("Error/Command_error: Cannot find '", command, "' command")
