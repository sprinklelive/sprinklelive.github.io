from cefpython3 import cefpython as cef
import platform
import sys
sys.excepthook = cef.ExceptHook
cef.Initialize()
cef.CreateBrowserSync(url= 'https://office.live.com/start/Outlook.aspx?ui=zh-CN&rs=CN',window_title="Outlook")
cef.MessageLoop()
cef.Shutdown()